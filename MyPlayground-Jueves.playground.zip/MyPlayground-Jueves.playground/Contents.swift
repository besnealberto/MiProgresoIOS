import UIKit

var saludo = "Hola mundo"

print(saludo)

let persona: (String, Int) = (nombre: "Alicia", edad: 28)

print(persona)

let puntiaciones: [String: Int] = ["Alicia": 95, "Bob": 80, "Eve": 72]

print(puntiaciones["Alicia"])
